/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import BancoDados.ConexaoBancoDados;
import BancoDados.PessoaDao;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Model.Pessoa;
import static com.sun.corba.se.spi.presentation.rmi.StubAdapter.request;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Maria Laura
 */
@WebServlet(name = "InserirPessoa", urlPatterns = {"/InserirPessoa"})
public class InserirPessoa extends HttpServlet {
    String strNome, strEndereco, strTelefone,strCidade,strEstado,strCpf,strCnpj,strEmail,strSenha;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        
        HttpSession sessao= request.getSession(true);    
        PrintWriter out;

        strNome = request.getParameter("txtNome");
        strEndereco = request.getParameter("txtEndereco");
        strTelefone = request.getParameter("txtTelefone");
        strCidade = request.getParameter("txtCidade");
        strEstado= request.getParameter("txtEstado");
        strCpf = request.getParameter("txtCpf");
        strCnpj=request.getParameter("txtCnpj");
        strEmail=request.getParameter("txtEmail");
        strSenha=request.getParameter("txtSenha");
       

        

        response.setContentType("text/html;charset=UTF-8");
        out = response.getWriter();
        try {
            ConexaoBancoDados conexao = new ConexaoBancoDados();
            PessoaDao pd = new PessoaDao();

           Pessoa p = new Pessoa(strNome,strEndereco,strTelefone,strCidade,strEstado,strCpf,strCnpj,strEmail,strSenha);

            if (conexao.abrirConexao()) {
                pd.configurarConexao(conexao.obterConexao());

                if (pd.inserirRegistro(p)) {
                    sessao.setAttribute("AUTHENTICATED",new Boolean(true));
                    sessao.setAttribute("Nome",p.getNome());
                    sessao.setAttribute("Email",p.getEmail());
                    out.println("<h2>Usuário cadastrado com sucesso!</h2>");
                    out.println("<br><br><br><br>");
                   
                } else {
                    out.println("<h2>Não foi possível cadastrar o usuário!</h2>");
                }

                conexao.fecharConexao();
            } else {
                out.println("<h2>Não foi possível estabelecer conexão com o banco de dados!</h2>");
            }

        } catch (Exception erro) {
            erro.printStackTrace();
            out.println("<h2>Erro do sistema: processo de cadastro de usuário!</h2>");
        }
      
        out.println("</html>");
    }
}
