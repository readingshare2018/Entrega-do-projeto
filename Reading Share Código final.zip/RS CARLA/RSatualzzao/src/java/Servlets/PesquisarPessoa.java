/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import BancoDados.ConexaoBancoDados;
import BancoDados.PessoaDao;
import Model.Pessoa;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Maria Laura
 */
@WebServlet(name = "PesquisarPessoa", urlPatterns = {"/PesquisarPessoa"})
public class PesquisarPessoa extends HttpServlet {
         ResultSet rsRegistro;
        PrintWriter out;
        String strEmail;
        String emailPessoa;
    @Override
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       

        strEmail = request.getParameter("txtEmail");

        response.setContentType("text/html;charset=UTF-8");
        out = response.getWriter();

     

        try {
            ConexaoBancoDados conexao = new ConexaoBancoDados();
           PessoaDao pd = new PessoaDao();

            if (conexao.abrirConexao()) {
                pd.configurarConexao(conexao.obterConexao());
                emailPessoa = pd.localizarRegistro(strEmail.toUpperCase());
                if (emailPessoa != null) {
                    rsRegistro = pd.lerRegistro(emailPessoa);
                    out.println("<h2>Identificação douduário:" + rsRegistro.getString("Identificacao_Usuario") + "<br>");
                    out.println("<br><br>");
                    out.println("<a href='editar_usuario.jsp?codigo_usuario=" + emailPessoa + "'>[Editar]</a> <a href='excluir_usuario.jsp?codigo_usuario=" + emailPessoa + "'>[Excluir]</a>");
                    out.println("<span class='LinkVoltar'><a href='javascript:history.back()'>[Voltar]</a></span>");
                } else {
                    out.println("<h2>Usuário não encontrando!</h2>");
                    out.println("<br><br><br>");
                    out.println("<p class='LinkVoltar'><a href='javascript:history.back()'>[Voltar]</a></p>");
                }
                conexao.fecharConexao();
            } else {
                out.println("<h2>Não foi possível estabelecer conexão com o banco de dados!</h2>");
            }

        } catch (Exception erro) {
            erro.printStackTrace();
            out.println("<h2>Erro do sistema:processo de cadastro do usuário!</h2>");
        }
        out.println("<p class='RodapePagina'>Copyright(c) 2015 - Editora Érica Ltda.</p>");
        out.println("</body>");
        out.println("</html>");
    }

}
