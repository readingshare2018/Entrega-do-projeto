/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import BancoDados.PessoaDao;
import BancoDados.ConexaoBancoDados;
import Model.Pessoa;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Maria Laura
 */
@WebServlet(name = "Login", urlPatterns = {"/Login"})
public class Login extends HttpServlet {
        
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         HttpSession sessao = request.getSession(true);
        ConexaoBancoDados con = new ConexaoBancoDados();//USEI ISSO
        boolean  teste = con.abrirConexao();//USEI ISSO/ tem que estar num if eu nao lembro aaaaa EU TO COM SONOOOOOO E com fome, vou ja fazer um rango 
        String email= request.getParameter("txtEmailLogin");//Apaga meus comentarios asjdhagd
        String senha= request.getParameter("txtSenhaLogin");
        Pessoa p = new Pessoa();
        PessoaDao pd = new PessoaDao();
        pd.configurarConexao(con.obterConexao());//USEI ISSO
        p.setEmail(email);
        p.setSenha(senha);
        System.out.print(email);

        System.out.print(p.getEmail());
        if(pd.login(p)){
            p =  pd.dadosPessoa(email);
            sessao.setAttribute("AUTHENTICATED",new Boolean(true));
            sessao.setAttribute("Nome",p.getNome());
            sessao.setAttribute("Email",p.getEmail());
            
            response.sendRedirect("NovaTelaUsuario.jsp");
           
        }else{
            System.out.println("Usuario nao encontrado");
            response.sendRedirect("TelaLogin.jsp");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
