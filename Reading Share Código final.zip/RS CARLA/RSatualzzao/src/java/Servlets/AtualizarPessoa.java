/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import BancoDados.ConexaoBancoDados;
import BancoDados.PessoaDao;
import Model.Pessoa;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Maria Laura
 */
@WebServlet(name = "AtualizarPessoa", urlPatterns = {"/AtualizarPessoa"})
public class AtualizarPessoa extends HttpServlet {
    String strNome, strEndereco, strTelefone,strCidade,strEstado,strCpf,strCnpj,strEmail,strSenha,strConfirmarEmail,strConfirmarSenha;   
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
 
        PrintWriter out;
        
        strNome = request.getParameter("txtNome");
        strEndereco = request.getParameter("txtEndereco");
        strTelefone = request.getParameter("txtTelefone");
        strCidade = request.getParameter("txtCidade");
        strEstado= request.getParameter("txtEstado");
        strCpf = request.getParameter("txtCpf");
        strCnpj=request.getParameter("txtCnpj");
        strEmail=request.getParameter("txtEmail");
        strSenha=request.getParameter("txtSenha");
       
 

            response.setContentType("text/html;charset=UTF-8");
            out = response.getWriter();

 try{
                ConexaoBancoDados conexao = new ConexaoBancoDados();
               PessoaDao pd = new PessoaDao();

                Pessoa p = new Pessoa(strNome,strEndereco,strTelefone,strCidade,strEstado,strCpf,strCnpj,strEmail,strSenha);

                if(conexao.abrirConexao()){
                    pd.configurarConexao(conexao.obterConexao());
                if(pd.alterarRegistro(p)){
                        out.println("<h2>Dados do usuário atualizados com sucesso!</h2>");
                        out.println("<br><br><br><br>");
              
                }else
                     out.println("<h2>Não foi possível atualizar os dados do usuário!</h2>");

                conexao.fecharConexao();
                }else{
                    out.println("<h2>Não foi possível estabelecer conexão com o banco de dados!</h2>");
                }

                }catch(Exception erro){
                erro.printStackTrace();
                     out.println("<h2>Erro do sistema: processo de atualização dos dados do usuário!</h2>");
                }
              
                     out.println("</html>");
 }
}
