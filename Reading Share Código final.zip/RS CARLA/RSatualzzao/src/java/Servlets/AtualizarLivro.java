/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import BancoDados.ConexaoBancoDados;
import BancoDados.LivroDao;
import Model.Livro;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Maria Laura
 */
@WebServlet(name = "AtualizarLivro", urlPatterns = {"/AtualizarLivro"})
public class AtualizarLivro extends HttpServlet {
    String strNome, strGenero, strSinopse,strAutor,strEstado;
    int strCodigo;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
 
        PrintWriter out;
        
        strNome = request.getParameter("txtNome");
        strGenero = request.getParameter("txtGenero");
        strSinopse = request.getParameter("txtSinopse");
        strAutor = request.getParameter("txtAutor");
        strCodigo= (Integer.parseInt(request.getParameter(("txtCodigo"))));
        
        
        response.setContentType("text/html;charset=UTF-8");
        out = response.getWriter();

      
        
        try{
            ConexaoBancoDados conexao = new ConexaoBancoDados();
            LivroDao ld = new LivroDao();

            Livro l = new Livro(strNome,strGenero,strSinopse,strAutor,strCodigo,strEstado);
                if(conexao.abrirConexao()){
                    ld.configurarConexao(conexao.obterConexao());
                if(ld.alterarRegistro(l)){
                    out.println("<h2>Dados do usuário atualizados com sucesso!</h2>");
                    out.println("<br><br><br><br>");
                
                }else
                    out.println("<h2>Não foi possível atualizar os dados do usuário!</h2>");

                    conexao.fecharConexao();
                }else{
                    out.println("<h2>Não foi possível estabelecer conexão com o banco de dados!</h2>");
                }

                }catch(Exception erro){
                    erro.printStackTrace();
                    out.println("<h2>Erro do sistema: processo de atualização dos dados do usuário!</h2>");
                }
               
                    out.println("</html>");
    
    }
}
