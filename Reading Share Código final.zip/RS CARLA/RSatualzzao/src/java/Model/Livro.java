/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Maria Laura
 */
public class Livro {
    private String nome,
                   genero,
                   sinopse,
                   autor,
                   estado;
    private int codigo;
    
    public Livro(){
        this.nome="";
        this.genero="";
        this.sinopse="";
        this.autor="";
        this.codigo=0;
        this.estado="";
     }
    
    public Livro(String nome, String genero, String sinopse, String autor, int codigo,String estado) {
        this.nome = nome;
        this.genero = genero;
        this.sinopse = sinopse;
        this.autor = autor;
        this.codigo = codigo;
        this.estado= estado;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getSinopse() {
        return sinopse;
    }

    public void setSinopse(String sinopse) {
        this.sinopse = sinopse;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
                         
    
}
