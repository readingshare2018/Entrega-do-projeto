/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BancoDados;

import Model.Livro;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Maria Laura
 */
public class LivroDao {
    private Connection conBanco;
    private PreparedStatement psComando;
    private ResultSet rsRegistros;

    public void configurarConexao(Connection conBanco) {
        this.conBanco = conBanco;
    }
    
        public boolean inserirRegistro(Livro l) {
        String strComandoSQL;

        try {
            strComandoSQL = "INSERT INTO Livro(nome,genero,sinopse,autor,codigo,estado)"
                    + "VALUES('" + l.getNome() + "',"
                    + "'" + l.getGenero() + "',"
                    + "'" + l.getSinopse() + "',"
                    + "'" + l.getAutor()+ "',"
                    + "'" + l.getCodigo()+ "',"
                    + "'" + l.getEstado() + "')";
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();

            return true;
        } catch (Exception erro) {
            erro.printStackTrace();
            return false;
        }
    }
        
    public boolean alterarRegistro(Livro l) {
        String strComandoSQL;

        try {
            strComandoSQL = "UPDATE Livro SET nome='" + l.getNome() + "'," 
                    + "genero = '" + l.getGenero() + "',"
                    + "sinopse = '" + l.getSinopse() + "',"
                    + "autor = '" + l.getAutor() + "',"
                    + "codigo = '" + l.getCodigo()+ "'," 
                    + "estado = '" + l.getEstado()+ "'," 
                    + "WHERE codigo = " + l.getCodigo();
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();

            return true;
        } catch (Exception erro) {
            erro.printStackTrace();
            return false;
        }
    }
 
    public boolean excluirRegistro(int codigo) {
        String strComandoSQL;

        try {
            strComandoSQL = "DELETE FROM Pessoa WHERE codigo = " + codigo;
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();

            return true;
        } catch (Exception erro) {
            erro.printStackTrace();
            return false;
        }
    }

      public int localizarRegistro(int strCodigo) {
        int codigoLivro=0;
        String strComandoSQL;

        try {
            strComandoSQL = "SELECT codigo FROM Livro WHERE codigo='" + strCodigo + "'";
            psComando = conBanco.prepareStatement(strComandoSQL);
            rsRegistros.next();

            codigoLivro = rsRegistros.getInt("txtCodigo");
        } catch (Exception erro) {
            erro.printStackTrace();
        }
        return codigoLivro;
    }

    public ResultSet lerRegistro(int codigoLivro) {
        String strComandoSQL;

        try {
            strComandoSQL = "SELECT * FROM Livro WHERE codigo = " + codigoLivro;
            psComando = conBanco.prepareStatement(strComandoSQL);
            rsRegistros = psComando.executeQuery();
            rsRegistros.next();

            return rsRegistros;
        } catch (Exception erro) {
            erro.printStackTrace();
            return null;
        }
    }

    public String localizarRegistro(String strCodigo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
