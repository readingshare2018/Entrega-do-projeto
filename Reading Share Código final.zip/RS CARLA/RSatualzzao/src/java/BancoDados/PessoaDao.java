/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BancoDados;
import Model.Pessoa;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Maria Laura
 */
public class PessoaDao {
    
     private Connection conBanco;
     private PreparedStatement psComando;
     private ResultSet rsRegistros;

    public void configurarConexao(Connection conBanco) {
        this.conBanco = conBanco;
    }
    
    
    public boolean inserirRegistro(Pessoa p) {
        String strComandoSQL;

        try {
            strComandoSQL = "INSERT INTO Pessoa(nome,endereco,telefone,cidade,estado,cpf,cnpj,email,senha)"
                    + "VALUES('" + p.getNome() + "',"
                    + "'" + p.getEndereco() + "',"
                    + "'" + p.getTelefone() + "',"
                    + "'" + p.getCidade() + "',"
                    + "'" + p.getEstado() + "',"
                    + "'" + p.getCpf() + "',"
                    + "'" + p.getCnpj() + "',"
                    + "'" + p.getEmail() + "',"
                    + "'" + p.getSenha() + "')";
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();

            return true;
        } catch (Exception erro) {
            erro.printStackTrace();
            return false;
        }
    }
    
    public boolean alterarRegistro(Pessoa p) {
        String strComandoSQL;

        try {
            strComandoSQL = "UPDATE Pessoa SET nome='" + p.getNome() + "'," 
                    + "endereco = '" + p.getEndereco() + "',"
                    + "telefone = '" + p.getTelefone() + "',"
                    + "cidade = '" + p.getCidade() + "',"
                    + "estado = '" + p.getEstado() + "',"
                    + "cpf = '" + p.getCpf() + "',"
                    + "cnpj = '" + p.getCnpj() + "',"
                    + "email = '" + p.getEmail() + "',"
                    + "senha = '" + p.getSenha() + "',"
                    + "WHERE email = " + p.getEmail();
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();

            return true;
        } catch (Exception erro) {
            erro.printStackTrace();
            return false;
        }
    }
    
    public boolean excluirRegistro(String email) {
        String strComandoSQL;

        try {
            strComandoSQL = "DELETE FROM Pessoa WHERE email = " + email;
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();

            return true;
        } catch (Exception erro) {
            erro.printStackTrace();
            return false;
        }
    }

      public String localizarRegistro(String strEmail) {
        String emailPessoa="";
        String strComandoSQL;

        try {
            strComandoSQL = "SELECT email FROM Pessoa WHERE email='" + strEmail + "'";
            psComando = conBanco.prepareStatement(strComandoSQL);
            rsRegistros.next();

            emailPessoa = rsRegistros.getString("txtEmail");
        } catch (Exception erro) {
            erro.printStackTrace();
        }
        return emailPessoa;
    }

    public ResultSet lerRegistro(String emailPessoa) {
        String strComandoSQL;

        try {
            strComandoSQL = "SELECT * FROM Pessoa WHERE email = " + emailPessoa;
            psComando = conBanco.prepareStatement(strComandoSQL);
            rsRegistros = psComando.executeQuery();
            rsRegistros.next();

            return rsRegistros;
        } catch (Exception erro) {
            erro.printStackTrace();
            return null;
        }
    }
     public Pessoa dadosPessoa(String email){
            String strComandoSQL;
            strComandoSQL="SELECT * from Pessoa WHERE email=" +email;
            Pessoa p = new Pessoa();
        
            
            
            try{
                psComando=conBanco.prepareStatement(strComandoSQL);
                psComando.setString(1, email);
                rsRegistros= psComando.executeQuery();
                
                if(rsRegistros.next()){
                    p.setNome(rsRegistros.getString("Nome"));
                    p.setEndereco(rsRegistros.getString("Endereco"));
                    p.setTelefone(rsRegistros.getString("Telefone"));
                    p.setCidade(rsRegistros.getString("Cidade"));
                    p.setEstado(rsRegistros.getString("Estado"));
                    p.setCpf(rsRegistros.getString("Cpf"));
                    p.setCnpj(rsRegistros.getString("Cnpj"));
                    p.setEmail(rsRegistros.getString("Email"));
                    p.setSenha(rsRegistros.getString("Senha"));
                   
                    
                }else{
                    return null;
                }
                rsRegistros.close();
                psComando.close();
                conBanco.close();
            }catch(SQLException e){
                e.printStackTrace();
            }
            
            return p;
     }
    public boolean login(Pessoa p) {
        String strComandoSQL;
        ArrayList<String> info= new ArrayList<String>();
        boolean permitir=false;
        strComandoSQL = "SELECT email,senha FROM Pessoa WHERE email='" + p.getEmail() + "' AND senha='"+ p.getSenha() +"'";
        try{
          
          psComando = conBanco.prepareStatement(strComandoSQL);
          /*psComando.setString(1,p.getEmail());
          psComando.setString(2,p.getSenha());*/
          rsRegistros= psComando.executeQuery();
          
          if(rsRegistros.next()){
              info.add(rsRegistros.getString("Email"));
              info.add(rsRegistros.getString("Senha"));
              
          } 
          
          if(info.get(0).equals(p.getEmail()) && info.get(1).equals(p.getSenha())){
              permitir= true;
          }
          rsRegistros.close();
          psComando.close();
          conBanco.close();
    }catch(Exception e){
        e.printStackTrace();
    }
    return permitir;
    }
    
    
}
