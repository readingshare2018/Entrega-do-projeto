/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BancoDados;
import java.sql.Connection;
import java.sql.DriverManager;


/**
 *
 * @author Maria Laura
 */
public class ConexaoBancoDados {
             Connection conBanco;
  
    public boolean abrirConexao(){
        String url = "jdbc:mysql://localhost/readingshare?user=root&password=carla";
        String url2 = "jdbc:mysql://localhost/readingshare?user=root&password=carla&useTimezone=true&serverTimezone=UTC";
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conBanco = DriverManager.getConnection(url2);
            return true;
        } catch (Exception erro) {
            erro.printStackTrace();
            return false;
        }
    
        }
    
       public boolean fecharConexao(){
        try{
            conBanco.close();
            return true;
        }catch (Exception erro){
            erro.printStackTrace();
            return false;
        }
    }
    
    public Connection obterConexao(){
        return conBanco;
    }
}
